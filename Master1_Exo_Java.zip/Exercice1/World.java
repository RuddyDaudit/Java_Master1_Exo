package Exercice1;

public class World {
	private int nbl;
	private int nbc;
	private boolean [][]mat;

	public World() {
		this(10,10);
	}
	public World(int nbl,int nbc) {
		this.nbl = nbl;
		this.nbc = nbc;
		this.mat = new boolean[nbl][nbc];
	}
	void setNbl(int nbl) {
		this.nbl = nbl;
	}
	void setNbc(int nbc) {
		this.nbc = nbc;
	}
	int getNbl() {
		return this.nbl;
	}
	int getNbc() {
		return this.nbc;
	}
	boolean getMat() {
		return this.mat[nbc][nbl];
	}
	 public void putsGreasyPaper(int x,int y){
		 this.mat[x][y] = true;
	 }
	 public void removesGreasyPaper(int x,int y) {
		 this.mat[x][y] = false;
	 } 
	 public boolean isDirty(int x, int y) {
		 if (getMat() == true) {
				 return true;
				}
		 else { 
			 return false;
			}
	 }
	 public String toString() {
		String s = "";
		for(int i = 0;i < 10; i++) {
			for( int j = 0; j < 0; j++) {
				if(this.mat[i][j] == true) {
					s+=".";
				}else {
					s+="x";;
				}
			}
		}
		return s;
	 }
}
