package Exercice1;

public class Jumper extends Robot {
	int deltax;
	public Jumper(int x, int y, World m) {
		super(x, y, m);
	}

	void visit(){
		movesTo(0,0);
		for(int i = 0; i <= deltax; i++) {
			movesTo(i,i*deltax);
		}
	}	
}
