package Exercice1;

public class TestRobot {
	public static void main (String args[]) {
		boolean t [][] = new boolean [10][10]; 
		World w = new World(10,10);
		w.putsGreasyPaper(10,10);
		w.toString();
		w.isDirty(10, 10);
		w.removesGreasyPaper(10, 10);
		w.toString();
		w.isDirty(10, 10);
	}
}
