package Exercice1;

public class DistractedCleaner extends Robot {
	public DistractedCleaner(int x, int y, World m) {
		super(x, y, m);
	}
	void visit() {
		movesTo(0,0);
		for(int i = 0; i < /// ; i+2) {
			for(int j = 0; j < /// ;j+2) {
				m.removesGreasyPaper(i,j);
			}
		}
	}
}
