package Exercice1;

public abstract class Polluter extends Robot{
	
	public Polluter(int x, int y, World m) {
		super(x, y, m);
	}
	void pollute() {
		this.m.putsGreasyPaper(this.getX(),this.getY());
	}
	
}
