package Exercice1;

abstract class Robot {
	private int posX;
	private int posY;
	protected World m;
	abstract void visit();
	public Robot (World m) {
		this(0,0,m);
	}
	public Robot(int x,int y,World m) {
		this.posX = x;
		this.posY = y;
		this.m = m;
	}
	void movesTo(int x, int y) {
		this.posX = x;
		this.posY = y;
	}
	public int getX() {
		return this.posX;
	}
	public int getY() {
		return this.posY;
	}
	
}
