package Exercice1;

public class Cleaner extends Robot {

	public Cleaner(int x, int y, World m) {
		super(x, y, m);
		
	}
	void clean() {
		m.removesGreasyPaper(this.getX(),this.getY());
	}
	void visit() {
		movesTo(0,0);
		for(int i = 0; i < /// ; i++) {
			for(int j = 0; j < /// ;j++) {
				m.removesGreasyPaper(i,j);
			}
		}
	}
}
