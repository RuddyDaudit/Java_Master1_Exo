package Exercice1;

public class Straighter extends Robot{
	int startingColumn;
	public Straighter(int x, int y, World m) {
		super(x, y, m);
	}		
	void visit() {
		movesTo(0,startingColumn);
		for (int j = 0; j < startingColumn;j++) {
			m.putsGreasyPaper(0,j);
		}
	}
}

