import java.io.*;
import java.net.*;

public class SlaveG42 implements Runnable{
    private Socket client;
    public SlaveG42(Socket Client){
        this.client = Client;
    }
    public SlaveG42() {
    }
    @Override
    public void run() {
        try {
            System.out.println("[START] new client.");
            //ObjectOutputStream Output = new ObjectOutputStream(client.getOutputStream());
            ObjectInputStream Input = new ObjectInputStream(client.getInputStream());
            String methode = (String) Input.readObject();
            switch(methode){
                case "Math":
                    String operation = (String) G42.Math.peek();
                    if(!operation.equals(null))
                    switch (operation){
                        case "Plus":
                            G42.Math.remove();
                            int id1 = (Integer) G42.Math.peek();
                            G42.Math.remove();
                            int id2 = (Integer) G42.Math.peek();
                            G42.Math.remove();
                            int add = MathGenuis.Caplus(id1, id2);
                            System.out.println("MathGenius:\n" +operation + " " + "("+ id1 + ","+ id2 + ")"+ " = " +add);
                            break;
                        case "Moins":
                            G42.Math.remove();
                            int i1 = (Integer) G42.Math.peek();
                            G42.Math.remove();
                            int i2 = (Integer) G42.Math.peek();
                            G42.Math.remove();
                            int mince = MathGenuis.Camince(i1, i2);
                            System.out.println("MathGenius:\n" +operation + " " + "("+ i1 +","+ i2 + ")"+ " = "+ mince);
                            break;
                        case "PI":
                            G42.Math.remove();
                            double pi = MathGenuis.CaPi();
                            System.out.println("MathGenius:\n" +operation +" = "+ pi);
                            break;
                        default:
                            System.out.println("Undefined operation");
                            break; 
                    }
                    break;
                case "CS" :
                    String obj = (String) G42.CS.peek();
                    switch(obj){
                        case "Fact":
                            G42.CS.remove();
                            String fact =  CSGenuis.Algofact();
                            System.out.println("CSGenius:\n"+ obj +" :\n"+fact );
                            break;
                        case "Fibo":
                            G42.CS.remove();
                            String fibo =  CSGenuis.Algofibo();
                            System.out.println("CSGenius:\n"+ obj +" :\n"+fibo );
                            break;
                        case "PGCD":
                            G42.CS.remove();
                            String pgcd =  CSGenuis.AlgoPgcd();
                            System.out.println("CSGenius:\n"+ obj +" :\n"+pgcd );
                            break;
                        default:
                            System.out.println("Undefined operation");
                            break; 
                    }
                    break;
                default:
                    G42.setIsFinished();
                    break;
            }
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
}
