public class CSGenuis  {
    synchronized public static String Algofact() {
        return "let rec fact = function\n"+"| 0 -> 1 \n"+"| n -> n * fact (n-1)\n";
    }
    synchronized public static String Algofibo() {
        return "let rec fibo n = match n with\n"+"| 0->0\n"+"| 1->1\n"+"| _->fibo(n-1)+fibo(n-2)\n";
    }
    synchronized public static String AlgoPgcd(){
        return "let pgcd x y =\n"+"let rec pg x y = \n"+"if (x mod y = 0) then y\n"+"else pg y (x mod y)\n"+"in pg x y";
    }
}

