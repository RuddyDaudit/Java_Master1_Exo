public class MathGenuis {
    synchronized public static int Caplus(int a, int b) {
        return a + b;
    }
    synchronized public static int Camince(int a, int b) {
        return a - b;
    }
    synchronized public static double CaPi() {
        return Math.PI;
    }
}
