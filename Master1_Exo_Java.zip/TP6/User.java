import java.io.*;
import java.net.*;
import java.util.*;

public class User {
    public static void main( String arg[]) throws ClassNotFoundException{
        try {
            final Scanner scanner = new Scanner(System.in);
            Socket client_s = new Socket("127.0.0.1",33333); 
            System.out.println("Connection [OK]!! ");
            // Creation d'un objet pour envoyer la data
            ObjectOutputStream Output = new ObjectOutputStream(client_s.getOutputStream());
            
            int t = 3; 
            while(t>0){
                String methode = scanner.nextLine();
                if (methode.equals("Math")){
                    Output.writeObject(methode);
                }
                else if  (methode.equals("CS")){
                    Output.writeObject(methode);
                }
                else if (methode.equals("End")){
                    client_s.close();
                    System.exit(0);
                }
                else {
                    Output.writeObject("this customer does not exist");
                }
                t--;
            }
            scanner.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
