import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
public class G42{
    public static boolean isFinished = false;
    public ExecutorService pool;
    public ServerSocket server;
    public static Queue <Object> Math = new LinkedList<Object>();
    public static Queue <String> CS = new LinkedList<String>();
    public G42(int port, int poolSize) throws IOException {
        server = new ServerSocket(port);
        pool = Executors.newFixedThreadPool(poolSize);
    }  
    public static boolean getIsFinished() {  
        return  G42.isFinished ;  
    }
    public static void setIsFinished() {  
        isFinished = !getIsFinished() ;  
    }  
    public ExecutorService getPool() {  
        return  this.pool ;  
    }
    public void setPool(ExecutorService pool) {  
        this.pool = pool ;  
    }
    public void manageRequest() throws IOException{
        System.out.println("Waiting for connections...");
        while (true) {
            try {
                if (isFinished) {
                    System.out.println("Shutting down the executor");
                    this.pool.shutdown();
                    server.close();
                    System.out.println("Fin du serveur");
                    System.exit(0);
                }
                this.pool.execute(new SlaveG42(server.accept()));
            } catch (IOException E) {
                E.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        G42 S ;
        try {
            S = new G42(33333, 10);
            // the elements of Genius math
            G42.Math.add("Plus");
            G42.Math.add(1);
            G42.Math.add(9);
            G42.Math.add("PI");
            G42.Math.add("Moins");
            G42.Math.add(10);
            G42.Math.add(9);
            // the elements of Genius Computer
            G42.CS.add("Fact");
            G42.CS.add("Fibo");
            G42.CS.add("PGCD");
            
            S.manageRequest();
        } catch (Exception E) {
            System.out.println(E);
            E.printStackTrace();
        }
    }
}