package Examen;
import java.util.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


import TP2.Server;
import TP2.Teacher;
public class Common {}
    
public class Slave implements Runnable{
        Socket client;
    
        public Slave(Socket client) {
            this.client = client;
        }
    
        @Override
        public void run() {
            try {
                System.out.println("[START] nouveau client");
                ObjectInputStream input_client = new ObjectInputStream(client.getInputStream());
                ObjectOutputStream output_client = new ObjectOutputStream(client.getOutputStream());
                
                if(input_client.readUTF()=="create") {

                		String nom = input_client.readUTF();
                    	String login = input_client.readUTF();
                    	String mdp = input_client.readUTF();
                
                    	Utilisateur.C.stream().filter(t->t.getLogin().equals(login));
                        Serveur.getAdd(nom,login,mdp);   
                        
                }else if(input_client.readUTF()=="liste") {
                    	
                    	List <String,String> ListOfUsers; 
    					ListOfUsers = Utilisateur.C.stream()
    					.collect(Collectors.toMap(
    						    Map.Utilisateur::getNom, 
    						    Map.Utilisateur::getLogin));
               
                }else if(input_client.readUTF()=="message") {
                	
                }

                    	
                    	
            } catch (Exception e) {
                System.out.println(e);
            }
        }
} 

public class Message {
    String utilisateur;
    Date date;
    ArrayList<utilisateur> destinataire;
    
    public Message(String utilisateur, Date date, ArrayList<utilisateur> destinataire) {
        this.utilisateur = utilisateur;
        this.date = date;
        this.destinataire = destinataire;
    }
    
   
}
public class Utilisateur {
	private String nom;
	private String login;
	private String mdp;
	
	static ArrayList <Utilisateur> C = new ArrayList<Utilisateur>();
	
	public Utilisateur(String nom,String login,String mdp) {
		this.nom = nom;
		this.login = login;
		this.mdp = mdp;
	}
	public Utilisateur() {
		
	}
	void setNom(String nom) {
		this.nom = nom;
	}
	void setLogin(String login) {
		this.login = login;
	}
	void setMdp(String mdp) {
		this.mdp = mdp;
	}
	String getNom() {
		return this.nom;
	}
	String getLogin(){
		return this.login;
	}
	String getMdp() {
		return this.mdp;
	}
	void addUtilisateur(Utilisateur c) {
		C.add(c);
	}
	void deleteUtilisateur(Utilisateur c) {
		C.remove(c);
	}
}