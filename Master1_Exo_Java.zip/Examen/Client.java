package Examen;
import java.util.*;
import java.util.ArrayList;

import TP2.Teacher;


public class Client {
	private String nom;
	private String login;
	private String mdp;
	
	static ArrayList <Client> C = new ArrayList<Client>();
	
	public Client(String nom,String login,String mdp) {
		this.nom = nom;
		this.login = login;
		this.mdp = mdp;
	}
	void setNom(String nom) {
		this.nom = nom;
	}
	void setLogin(String login) {
		this.login = login;
	}
	void setMdp(String mdp) {
		this.mdp = mdp;
	}
	String getNom() {
		return this.nom;
	}
	String getLogin(){
		return this.login;
	}
	String getMdp() {
		return this.mdp;
	}
	void addClient(Client c) {
		C.add(c);
	}
	void deleteClient(Client c) {
		C.remove(c);
	}
	
	public static void main(String[]args) {
		Client aClient =  new Client ("Ruddy","Nox","azerty");
		Client bClient =  new Client ("Jeremie","Luffy","qwerty");
		Message nMessage() = new Message(aClient,listOfDestinataire,"2022-12-15");
		
	}
	
}
