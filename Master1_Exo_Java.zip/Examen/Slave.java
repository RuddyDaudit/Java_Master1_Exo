package Examen;

public class Slave {

}
