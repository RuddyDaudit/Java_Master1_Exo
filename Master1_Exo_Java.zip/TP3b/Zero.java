package TP3b;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class Zero implements Runnable {
	String fichier;
	Ax test;
	public Zero (String f,Ax test) {
		this.fichier = f;
		this.test = test;
	}
	
	@Override
	public void run() {
		 try {
			byte b[] = Digest.md5(this.fichier);
			Ex.newResult(Digest.md5(this.fichier));
			//cette ligne 
			this.test.newResult(b);
			//////////////
		} catch (NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
		 
	}
	    
	public static void main() {
		Zero z = new Zero("src/TP3b/Zero.java");
		Thread T  = new Thread(z);
		T.start();
		try {
			T.join();

			
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
