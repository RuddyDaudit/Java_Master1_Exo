package TP3b;

import java.io.IOException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;

public class Ax{
	public void newResult(byte[]d) throws NoSuchAlgorithmException, IOException{
		 String hex = new BigInteger(1,d).toString(16);
        System.out.println(hex);
   }
}