package TP2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
	private static int port;
	private static int poolSize;
	boolean isFinished;
	private ExecutorService pool;
	private ServerSocket s;
	static ArrayList <Teacher> t;
	
	public Server(int port,int poolSize) throws IOException{
		this.port = port;
		this.poolSize = poolSize;
		this.pool = Executors.newFixedThreadPool(poolSize);
		try {
			this.s = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static int getPort() {
		return port;
	}
	public static void setPort(int port) {
		Server.port = port;
	}
	public static int getPoolSize() {
		return poolSize;
	}
	public static void setPoolSize(int poolSize) {
		Server.poolSize = poolSize;
	}
	static ArrayList <Teacher> listOfTeachers(){
		return Server.t;
	}
	
	public void start(){
	    try {
	        System.out.println("Waiting for connections...");
	        while(true){
	            this.pool.execute(new ServerTask(s.accept()));
	            System.out.println("Connection  [OK] ");
	        }

	    } catch (IOException E) {
	        E.printStackTrace();
	    }
	}
}
