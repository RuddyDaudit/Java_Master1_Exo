package TP2;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Slave implements Runnable {
	
	
	public Slave(DatagramSocket socket) {
		
	}
	
	@Override
	public void run() {
		
	}
	

}
