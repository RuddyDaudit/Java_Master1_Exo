package TP2;
import java.util.*;
import java.util.stream.Collectors;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.HashMap;

class ServerTask implements Runnable{
	    private Socket client;
	    
	    public ServerTask(Socket client){
	        this.client = client;
	    }

		@Override
		public void run() {
			
			  // Creating an outputstream to send data
            try {
				ObjectOutputStream output = new ObjectOutputStream(this.client.getOutputStream());
				ObjectInputStream input = new ObjectInputStream(this.client.getInputStream());
				int x = input.readInt();
				//String req = input.readUTF();
				if(x == 1) {
					String nameTeacher = input.readUTF();
					Integer age = input.readInt();
					float salary = input.readFloat();
					Disicipline dSlave ;
					String d = input.readUTF();
					dSlave = Disicipline.valueOf(d);
					
					//ArrayList <Teacher> listOfTeachers = new ArrayList<Teacher>();
					//Teacher a = new Teacher(nameTeacher,age,salary,dSlave);
					
					
				}else if(x == 2) {
					//liste des profs par disciplines
					Disicipline dSlave ;
					String rec = input.readUTF();
					dSlave = Disicipline.valueOf(rec);
					
					Server.listOfTeachers().stream()
					.filter(t->t.getDiscipline().equals(dSlave))
					.collect(Collectors.toList());
				}else if(x == 3) {
					//Computing the mean of salaries of the teachers of a given discipline.

				}else if(x == 4) {
					// Return the number of teachers of a given discipline.
				}else if(x == 5) {
					List <String,String> ListOfID; 
					
					ListOfID = Server.listOfTeachers().stream()
					.mapToInt(Teacher::getID)
					.collect(ArrayList::new,ArrayList::add, ArrayList::addAll);
					
					output.writeObject(ListOfID);
				}
				else if(x == 6) {
					HashMap<Integer,Integer> ListOfNameById = new HashMap<Integer,Integer>();
					Integer id = input.readInt();
					Thread thread = new Thread();
					thread.start();
					
					
				}
            } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            
            
            
		}
}