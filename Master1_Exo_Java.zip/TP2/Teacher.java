package TP2;
import java.util.*;
import java.util.stream.Collectors;
enum Disicipline {CS, MATH, PHYSICS, CHEMISTRY,
	ENGLISH};
public class Teacher {
private String name;
Integer age;
float salary;
int ID;
Disicipline  discipline;
static ArrayList <Teacher> T = new ArrayList<Teacher>();

public Teacher(String name,Integer age,float salary,Disicipline  discipline,int ID) {
	this.name = name;
	this.age = age;
	this.salary = salary;
	this.discipline = discipline;
	this.ID = ID;
}
void setName(String name) {
	this.name = name;
	}
void setAge(Integer age) {
	this.age = age;
}

void setSalary(float salary) {
	this.salary = salary;
	}
void setDiscipline(Disicipline discipline) {
	this.discipline = discipline;
	}

String getName() {
	return this.name;
	}
int getAge() {
	return this.age;
}

float getSalary() {
	return this.salary;
	}
Disicipline getDiscipline() {
	return this.discipline;
	}
int getID() {
	return this.ID;
}
void addTeacher(Teacher e) {
	T.add(e);
}
void deleteTeacher(Teacher e) {
	T.remove(e);
}
int returnAge(String n) {
	return T.stream()
	   .filter(t->t.getName().equals(n))
	   .map(Teacher::getAge)
	   .findAny().orElse(0);
	   }
double moyenneAge(ArrayList<Teacher> l) {
	return l.stream()
	.mapToInt(Teacher::getAge)
	.average()
	.orElse(0);
}
double moyenneSalaire(ArrayList<Teacher> lt) {
	return lt.stream()
	.filter(l->l.getSalary() > 40.00 && l.getSalary() < 60.00)
	.mapToDouble(Teacher::getSalary) 
	.average()
	.orElse(0);
}
Map<Disicipline, Double> GroupemoyenneSalaire(ArrayList<Teacher> lt) {
	return lt.stream()
	.filter(l->l.getSalary() > 40.00 && l.getSalary() < 60.00)
	.collect(Collectors.groupingBy(Teacher::getDiscipline,Collectors.averagingDouble(Teacher::getSalary)));
}

}
