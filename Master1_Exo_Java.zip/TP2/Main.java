package TP2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
	public void main() {
	ArrayList <Teacher> listOfTeachers = new ArrayList<Teacher>();
	Teacher a = new Teacher("Daudit",26,(float)1700.00,Disicipline.MATH);
	Teacher b = new Teacher("Hamada",26,(float)1600.00,Disicipline.CHEMISTRY);
	Teacher c = new Teacher("Hamilton",26,(float)1500.00,Disicipline.PHYSICS);
	Teacher d = new Teacher("Drame",26,(float)1670.00,Disicipline.ENGLISH);
	
		try {
			Server s = new Server(33333,10);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}